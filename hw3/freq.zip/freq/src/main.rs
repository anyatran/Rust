use std::io;
use std::io::BufferedReader;
use std::collections::HashMap;

fn main() {
    let mut stdin = io::BufferedReader::new(io::stdin());
    let buf: String = stdin.read_to_string().unwrap();
    let f: HashMap<&str, usize> = freq(&buf);        
    for (key, val) in f.iter() {
        println!("{}: {}", key, val);
    }
}

pub fn freq<'a>(c: & 'a String) -> HashMap<&'a str, usize> {
    let content: &str = c.as_slice();
    let mut words: HashMap<&str, usize> = HashMap::new();
    for word in content.words() {
        match words.insert(word, 1u) {
            Some(count) =>  { words.insert(word, count + 1) },
            None => {
                words.insert(word, 1u) }
        };
    }
    words
}

#[cfg(test)]
mod freq_tests {
    use super::freq;
    use std::io;
    use std::collections::HashMap;

    #[test]
    fn counts_1() {
        let mut expected: HashMap<&str, usize> = HashMap::new();
        expected.insert("nini", 1);
        expected.insert("mimi", 2);
        expected.insert("mimi,", 1);
        expected.insert("hello", 2);
        expected.insert("Anya", 1);
        expected.insert("hEllo", 1);
        expected.insert("anya", 1);
        expected.insert("fdfd", 1);
        let s_pointer: &str = "hello anya hello nini fdfd mimi mimi mimi, Anya hEllo";
        let s: String = s_pointer.to_string();
        assert_eq!(freq(&s), expected);
    }
}
